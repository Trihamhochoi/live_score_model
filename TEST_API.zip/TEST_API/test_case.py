from TEST_API.Old.live_data_format_v4 import Engine
import time
import json
import copy

# TestCase

match_id = 77926259 #77623787 #77592032
event_position = 0
event_code_ids = []

json_file_path = 'rb_code.json'
# Open the file and load the JSON data
with open(json_file_path, 'r') as json_file:
    rb_code = json.load(json_file)

match = Engine(match_id=match_id,
               event_position=event_position,
               event_code_ids=event_code_ids,
               selected_ids=rb_code)

# Create log file for a match sample
logs = []
for i in range(1800):
    # get FT event
    match.UpdateLogs(isFT=True)
    logs.append(copy.deepcopy(match.event_data_ft))
    # get HT event
    # match.UpdateLogs(False)
    # logs.append(copy.deepcopy(match.event_data_ht))

    # simulate request every 1 seconds
    time.sleep(1)
    pass

print(logs)

with open(file=f'test_case_{match_id}.json',
          mode='w',
          encoding='utf-8') as f:
    json.dump(logs, f, ensure_ascii=False, indent=4)
